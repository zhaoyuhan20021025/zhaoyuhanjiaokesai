export function randomPoints(center,range,num){
    return new Array(num).fill(0).map(item => center)
}